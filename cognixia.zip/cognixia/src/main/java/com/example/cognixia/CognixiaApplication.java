package com.example.cognixia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CognixiaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CognixiaApplication.class, args);
	}

}
